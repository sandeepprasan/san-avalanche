// Copyright (C) 2022, Ava Labs, Inc. All rights reserved.
// See the file LICENSE for licensing terms.
package main

import (
	"github.com/ava-labs/avalanche-network-runner/cmd"
)

func main() {
	cmd.Execute()
}
